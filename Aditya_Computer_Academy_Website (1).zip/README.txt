ADITYA COMPUTER ACADEMY WEBSITE
=================================

Files:
- index.html : complete responsive website

Included:
- Home, Courses, About, AI Tools, Fees/Payment, Certificate Verification, Contact
- ADCA/DCA/CCC/DTP/PGDCA/Tally Prime/Typing/MS Office courses
- Course View modal and Enroll Now admission form
- Student name, father name, address, contact, education, course, passport photo
- Declaration and successful submission notification
- Demo Admin Panel with browser-local admission storage and CSV export
- Certificate verification demo
- WhatsApp and Instagram buttons
- Responsive mobile layout

IMPORTANT FOR PRODUCTION:
1. Replace "Academy address to be added" with the real address.
2. Change demo admin username/password.
3. The current admin/admission system uses browser localStorage only. For real multi-device admin access, use a backend/database.
4. Real online payment requires a UPI ID/QR or payment gateway account (Razorpay/Cashfree/PayU etc.) and backend/webhook verification.
5. Certificate verification should use a real database before public launch.
6. Add academy logo/photos as desired.
